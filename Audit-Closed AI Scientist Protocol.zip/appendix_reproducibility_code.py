﻿#!/usr/bin/env python3
"""Appendix reproducibility code for this manuscript.

This script uses only Python standard library modules. It reproduces all
synthetic numbers reported in Section "Synthetic Self-Driving-Lab Demonstration"
and writes a machine-readable manifest.

Usage:
  python appendix_reproducibility_code.py

Outputs:
  - appendix_reproducibility_results.json
  - Console summary
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
import platform
import random
import statistics
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

BASE_SEED = 20260222
OUT_PATH = Path("appendix_reproducibility_results.json")

LAMBDA_GRID = [0.1, 0.3, 0.5, 0.7, 0.9]
LAMBDA_WEIGHTS = [1.0 / len(LAMBDA_GRID)] * len(LAMBDA_GRID)
EVALUE_THRESHOLD = 100.0  # 1 / alpha with alpha = 0.01


def clip(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def quantile_sorted(sorted_values: Sequence[float], q: float) -> float:
    """Right-continuous empirical quantile for q in (0,1]."""
    if not sorted_values:
        raise ValueError("empty sample")
    n = len(sorted_values)
    idx = max(0, min(n - 1, math.ceil(q * n) - 1))
    return sorted_values[idx]


def draw_context(rng: random.Random, probs: Sequence[float]) -> int:
    u = rng.random()
    cum = 0.0
    for i, p in enumerate(probs):
        cum += p
        if u <= cum:
            return i
    return len(probs) - 1


def mixture_eprocess(xs: Iterable[float]) -> Tuple[float, Optional[int]]:
    """Return final mixture e-value and first threshold crossing index (1-based)."""
    e_terms = [1.0] * len(LAMBDA_GRID)
    crossing: Optional[int] = None
    for i, x in enumerate(xs, 1):
        for j, lam in enumerate(LAMBDA_GRID):
            e_terms[j] *= 1.0 + lam * x
        mix = sum(w * e for w, e in zip(LAMBDA_WEIGHTS, e_terms))
        if crossing is None and mix >= EVALUE_THRESHOLD:
            crossing = i
    final_mix = sum(w * e for w, e in zip(LAMBDA_WEIGHTS, e_terms))
    return final_mix, crossing


def update_mixture_state(state: List[float], x: float) -> float:
    """One-step update for standard mixture betting process."""
    for j, lam in enumerate(LAMBDA_GRID):
        state[j] *= 1.0 + lam * x
    return sum(w * e for w, e in zip(LAMBDA_WEIGHTS, state))


# ---------------------------------------------------------------------------
# 1) Outlier resilience
# ---------------------------------------------------------------------------
def simulate_outlier_scenario(
    *,
    mean_gain: float,
    outlier_rate: float,
    seed: int,
    runs: int = 1500,
    samples_per_run: int = 220,
    sigma: float = 0.28,
    integrity_qmax: float = 0.12,
) -> Dict[str, float]:
    rng = random.Random(seed)

    strict_abort = 0
    strict_full = 0
    sanitized_full = 0
    integrity_fail = 0

    for _ in range(runs):
        strict_xs: List[float] = []
        aborted = False
        for _ in range(samples_per_run):
            if rng.random() < outlier_rate:
                aborted = True
                break
            strict_xs.append(clip(rng.gauss(mean_gain, sigma), -1.0, 1.0))
        if aborted:
            strict_abort += 1
        else:
            _, cross = mixture_eprocess(strict_xs)
            if cross is not None:
                strict_full += 1

        sanitized_xs: List[float] = []
        anomalies = 0
        for _ in range(samples_per_run):
            if rng.random() < outlier_rate:
                anomalies += 1
                x = 0.0
            else:
                x = clip(rng.gauss(mean_gain, sigma), -1.0, 1.0)
            sanitized_xs.append(x)
        _, cross = mixture_eprocess(sanitized_xs)
        if cross is not None:
            sanitized_full += 1
        if anomalies / samples_per_run > integrity_qmax:
            integrity_fail += 1

    return {
        "strict_abort": strict_abort / runs,
        "strict_full": strict_full / runs,
        "sanitized_full": sanitized_full / runs,
        "integrity_fail": integrity_fail / runs,
    }


# ---------------------------------------------------------------------------
# 2) Drift-mode bounded-horizon recovery
# ---------------------------------------------------------------------------
def simulate_drift_recovery(
    *,
    seed: int,
    runs: int = 700,
    max_epoch: int = 60,
    p_base: float = 0.075,
    p_slope: float = 0.04,
    p_cap: float = 0.50,
) -> Dict[str, float]:
    delays: List[int] = []
    for r in range(runs):
        rng = random.Random(seed + r * 19)
        exit_delay: Optional[int] = None
        for epoch in range(1, max_epoch + 1):
            p_exit = min(p_base + p_slope * epoch, p_cap)
            if rng.random() < p_exit:
                exit_delay = epoch
                break
        if exit_delay is not None:
            delays.append(exit_delay)

    exit_rate = len(delays) / runs
    stuck_rate = 1.0 - exit_rate
    sorted_delays = sorted(delays)

    return {
        "exit_rate": exit_rate,
        "stuck_rate": stuck_rate,
        "median_exit": statistics.median(sorted_delays),
        "p90_exit": quantile_sorted(sorted_delays, 0.90),
    }


# ---------------------------------------------------------------------------
# 3) Partial-Byzantine witness growth
# ---------------------------------------------------------------------------
def simulate_byzantine_growth(
    *,
    seed: int,
    runs: int = 1200,
    horizon: int = 400,
    gamma_honest: float = 0.35,
    honest_log_growth_mean: float = 0.05,
    honest_log_growth_sd: float = 0.12,
) -> Dict[str, float]:
    crossing_times: List[int] = []
    for r in range(runs):
        rng = random.Random(seed + r * 13)
        e_honest = 1.0
        crossed: Optional[int] = None
        for n in range(1, horizon + 1):
            e_honest *= math.exp(rng.gauss(honest_log_growth_mean, honest_log_growth_sd))
            e_agg = (1.0 - gamma_honest) + gamma_honest * e_honest
            if crossed is None and e_agg >= EVALUE_THRESHOLD:
                crossed = n
        if crossed is not None:
            crossing_times.append(crossed)

    crossing_times_sorted = sorted(crossing_times)
    asymptotic_rate = honest_log_growth_mean
    hitting_time_scale = (math.log(EVALUE_THRESHOLD) + math.log(1.0 / gamma_honest)) / asymptotic_rate

    return {
        "cross_rate": len(crossing_times) / runs,
        "median_cross": statistics.median(crossing_times_sorted),
        "p90_cross": quantile_sorted(crossing_times_sorted, 0.90),
        "asymptotic_rate_lower_bound": asymptotic_rate,
        "hitting_time_scale": hitting_time_scale,
    }


# ---------------------------------------------------------------------------
# 4) Novelty dual dynamics under legal-spam pressure
# ---------------------------------------------------------------------------
def simulate_novelty_dynamics(
    *,
    defended: bool,
    seed: int,
    runs: int = 800,
    epochs: int = 160,
) -> Dict[str, float]:
    mean_accept_rates: List[float] = []
    final_nus: List[float] = []

    for r in range(runs):
        rng = random.Random(seed + r * 31)
        nu = 0.8
        honest_accept = 0
        honest_total = 0

        for _ in range(epochs):
            candidates: List[Tuple[float, float, float, bool]] = []

            for _ in range(12):
                novelty = max(0.0, rng.gauss(0.08, 0.04))
                cost = max(0.2, rng.gauss(3.2, 0.4))
                signal = clip(rng.gauss(0.08, 0.05), 0.0, 1.0)
                candidates.append((novelty, cost, signal, False))

            for _ in range(2):
                novelty = max(0.0, rng.gauss(2.0, 0.45))
                cost = max(0.2, rng.gauss(1.3, 0.18))
                signal = clip(rng.gauss(0.75, 0.12), 0.0, 1.0)
                candidates.append((novelty, cost, signal, True))

            if defended:
                eligible: List[Tuple[float, float, float, bool]] = []
                slashed = 0
                for novelty, cost, signal, is_honest in candidates:
                    if signal >= 0.25:
                        eligible.append((novelty, cost, signal, is_honest))
                    else:
                        slashed += 1
                mean_cost = sum(c[1] for c in eligible) / len(eligible) if eligible else 0.0
                mean_cost = clip(mean_cost, 0.5, 2.0)
                nu = clip(nu + 0.05 * (mean_cost - 1.15) - 0.00015 * slashed, 0.0, 25.0)
            else:
                mean_cost = sum(c[1] for c in candidates) / len(candidates)
                nu = clip(nu + 0.05 * (mean_cost - 1.15), 0.0, 25.0)

            for novelty, cost, _signal, is_honest in candidates:
                if is_honest:
                    honest_total += 1
                    if novelty - nu * cost > 0.0:
                        honest_accept += 1

        mean_accept_rates.append(honest_accept / honest_total)
        final_nus.append(nu)

    return {
        "honest_accept_rate": sum(mean_accept_rates) / len(mean_accept_rates),
        "mean_final_nu": sum(final_nus) / len(final_nus),
    }


# ---------------------------------------------------------------------------
# 5) Adaptive contextual sampling with IPS-normalized increments
# ---------------------------------------------------------------------------
def simulate_adaptive_contextual(
    *,
    policy_pi: Sequence[float],
    alt: bool,
    seed: int,
    runs: int = 2000,
    horizon: int = 240,
) -> Dict[str, float]:
    q_progress = [0.5, 0.3, 0.2]
    means = [0.03, 0.05, 0.08] if alt else [0.0, 0.0, 0.0]
    sds = [0.15, 0.2, 0.55]

    c_w = max(q_progress[i] / policy_pi[i] for i in range(len(q_progress)))

    crossing_times: List[int] = []
    log_e_values: List[float] = []

    for r in range(runs):
        rng = random.Random(seed + r * 23)
        xs: List[float] = []
        for _ in range(horizon):
            ctx = draw_context(rng, policy_pi)
            raw = clip(rng.gauss(means[ctx], sds[ctx]), -1.0, 1.0)
            weight = q_progress[ctx] / policy_pi[ctx]
            x_tilde = clip((weight * raw) / c_w, -1.0, 1.0)
            xs.append(x_tilde)
        final_e, cross = mixture_eprocess(xs)
        log_e_values.append(math.log(max(final_e, 1e-12)))
        if cross is not None:
            crossing_times.append(cross)

    out: Dict[str, float] = {
        "cross_rate": len(crossing_times) / runs,
        "mean_log_e": sum(log_e_values) / len(log_e_values),
        "max_weight_ratio": c_w,
    }
    if crossing_times:
        s = sorted(crossing_times)
        out["median_cross"] = statistics.median(s)
        out["p90_cross"] = quantile_sorted(s, 0.90)
    return out


# ---------------------------------------------------------------------------
# 6) High-cw stress: fixed IPS vs variance-adaptive betting
# ---------------------------------------------------------------------------
def simulate_ips_paralysis_stress(
    *,
    seed: int,
    runs: int = 2000,
    horizon: int = 280,
) -> Dict[str, float]:
    # Progress reference emphasizes a context that exploration policy rarely samples.
    q_progress = [0.4] + [0.6 / 9.0] * 9
    policy = [0.0004] + [0.9996 / 9.0] * 9
    c_w = max(q / p for q, p in zip(q_progress, policy))

    means_alt = [0.03, 0.08, 0.08, 0.08, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03]
    means_null = [0.0] * 10
    sd = [0.25] * 10

    def one_mode(alt: bool) -> Dict[str, float]:
        means = means_alt if alt else means_null

        fixed_hits: List[int] = []
        fixed_logs: List[float] = []

        adapt_hits: List[int] = []
        adapt_logs: List[float] = []

        adapt_grid = [0.4, 0.8, 1.2, 1.6]
        adapt_weights = [1.0 / len(adapt_grid)] * len(adapt_grid)

        for r in range(runs):
            rng = random.Random(seed + r * 19)

            # Fixed-c_w normalization (can become nearly zero increments).
            e_fixed = [1.0] * len(LAMBDA_GRID)
            fixed_cross: Optional[int] = None

            # Variance-adaptive local-bounded betting.
            e_adapt = [1.0] * len(adapt_grid)
            adapt_cross: Optional[int] = None
            v_hat = 1.0

            for i in range(1, horizon + 1):
                x = draw_context(rng, policy)
                base = clip(rng.gauss(means[x], sd[x]), -1.0, 1.0)
                w = q_progress[x] / policy[x]
                y_raw = w * base

                # Fixed normalization by global worst-case ratio.
                x_fixed = clip(y_raw / c_w, -1.0, 1.0)
                mix_fixed = update_mixture_state(e_fixed, x_fixed)
                if fixed_cross is None and mix_fixed >= EVALUE_THRESHOLD:
                    fixed_cross = i

                # Variance-adaptive per-step betting fraction.
                # lambda_i is reduced when predictable variance is large,
                # and also bounded by local support to keep (1+lambda_i y_raw)>0.
                for j, lam0 in enumerate(adapt_grid):
                    lam_i = min(lam0 / math.sqrt(v_hat + 1e-8), 0.5 / max(1.0, w))
                    e_adapt[j] *= 1.0 + lam_i * y_raw
                mix_adapt = sum(a * b for a, b in zip(adapt_weights, e_adapt))
                if adapt_cross is None and mix_adapt >= EVALUE_THRESHOLD:
                    adapt_cross = i

                v_hat = 0.98 * v_hat + 0.02 * (y_raw * y_raw)

            mix_fixed = sum(wg * e for wg, e in zip(LAMBDA_WEIGHTS, e_fixed))
            mix_adapt = sum(a * b for a, b in zip(adapt_weights, e_adapt))

            fixed_logs.append(math.log(max(mix_fixed, 1e-12)))
            adapt_logs.append(math.log(max(mix_adapt, 1e-12)))

            if fixed_cross is not None:
                fixed_hits.append(fixed_cross)
            if adapt_cross is not None:
                adapt_hits.append(adapt_cross)

        out: Dict[str, float] = {
            "fixed_cross_rate": len(fixed_hits) / runs,
            "fixed_mean_log_e": sum(fixed_logs) / len(fixed_logs),
            "adaptive_cross_rate": len(adapt_hits) / runs,
            "adaptive_mean_log_e": sum(adapt_logs) / len(adapt_logs),
        }
        if adapt_hits:
            s = sorted(adapt_hits)
            out["adaptive_median_cross"] = statistics.median(s)
            out["adaptive_p90_cross"] = quantile_sorted(s, 0.90)
        return out

    return {
        "max_weight_ratio": c_w,
        "alternative": one_mode(True),
        "null": one_mode(False),
    }


# ---------------------------------------------------------------------------
# 7) Root-debt decay attack: legacy vs exogenous-certified counter
# ---------------------------------------------------------------------------
def simulate_root_debt_attack(
    *,
    seed: int,
    runs: int = 1500,
    horizon: int = 120,
    decay_lambda: float = 0.10,
    kappa_floor: float = 0.20,
) -> Dict[str, float]:
    m_legacy: List[int] = []
    m_defended: List[int] = []
    kappa_legacy: List[float] = []
    kappa_defended: List[float] = []

    for r in range(runs):
        rng = random.Random(seed + r * 7)

        ml = 0
        md = 0

        for _ in range(horizon):
            # Adversarial statistical drift pressure.
            drift_trigger = rng.random() < 0.70
            # True exogenous environment shift.
            exogenous = rng.random() < 0.06

            if drift_trigger:
                ml += 1

            if drift_trigger:
                if exogenous:
                    certified_external = rng.random() < 0.90
                else:
                    certified_external = rng.random() < 0.015
                if certified_external:
                    md += 1

        m_legacy.append(ml)
        m_defended.append(md)

        kappa_legacy.append(max(kappa_floor, math.exp(-decay_lambda * ml)))
        kappa_defended.append(max(kappa_floor, math.exp(-decay_lambda * md)))

    return {
        "median_m_legacy": statistics.median(m_legacy),
        "median_m_defended": statistics.median(m_defended),
        "median_kappa_legacy": statistics.median(kappa_legacy),
        "median_kappa_defended": statistics.median(kappa_defended),
        "low_kappa_rate_legacy": sum(1 for k in kappa_legacy if k <= 0.25) / runs,
        "low_kappa_rate_defended": sum(1 for k in kappa_defended if k <= 0.25) / runs,
    }


# ---------------------------------------------------------------------------
# 8) Drift fault localization by subgraph-local e-processes
# ---------------------------------------------------------------------------
def simulate_fault_localization(
    *,
    seed: int,
    runs: int = 1500,
    horizon: int = 180,
) -> Dict[str, float]:
    unaffected_uptime_global = 0.0
    unaffected_uptime_local = 0.0
    false_local_quarantine = 0.0

    for r in range(runs):
        rng = random.Random(seed + r * 17)

        drift_a = rng.random() < 0.5
        drift_b = not drift_a

        ea = [1.0] * len(LAMBDA_GRID)
        eb = [1.0] * len(LAMBDA_GRID)
        trig_a = False
        trig_b = False

        uptime_global = 0
        uptime_local = 0
        false_local = 0

        for _ in range(horizon):
            xa = clip(rng.gauss(0.07 if drift_a else 0.0, 0.24), -1.0, 1.0)
            xb = clip(rng.gauss(0.07 if drift_b else 0.0, 0.24), -1.0, 1.0)

            if (not trig_a) and update_mixture_state(ea, xa) >= EVALUE_THRESHOLD:
                trig_a = True
            if (not trig_b) and update_mixture_state(eb, xb) >= EVALUE_THRESHOLD:
                trig_b = True

            if drift_a:
                # unaffected branch is B
                if not (trig_a or trig_b):
                    uptime_global += 1
                if not trig_b:
                    uptime_local += 1
                if trig_b:
                    false_local += 1
            else:
                # unaffected branch is A
                if not (trig_a or trig_b):
                    uptime_global += 1
                if not trig_a:
                    uptime_local += 1
                if trig_a:
                    false_local += 1

        unaffected_uptime_global += uptime_global / horizon
        unaffected_uptime_local += uptime_local / horizon
        false_local_quarantine += false_local / horizon

    return {
        "unaffected_uptime_global_freeze": unaffected_uptime_global / runs,
        "unaffected_uptime_localized": unaffected_uptime_local / runs,
        "false_local_quarantine_rate": false_local_quarantine / runs,
    }


# ---------------------------------------------------------------------------
# 9) Sentinel hierarchy stress test
# ---------------------------------------------------------------------------
def simulate_sentinel_hierarchy(
    *,
    seed: int,
    runs: int = 2500,
) -> Dict[str, float]:
    false_single = 0
    calibrations_single = 0

    false_hier = 0
    calibrations_hier = 0
    freeze_hier = 0

    for r in range(runs):
        rng = random.Random(seed + r * 11)

        sensor_drift = rng.random() < 0.40
        primary_degraded = rng.random() < 0.03
        secondary_degraded = rng.random() < 0.20

        # Single-sentinel design: cannot distinguish sentinel degradation from sensor drift.
        trigger_single = sensor_drift or primary_degraded or secondary_degraded
        if trigger_single:
            calibrations_single += 1
            if primary_degraded or secondary_degraded:
                false_single += 1

        # Hierarchical sentinels:
        # 1) primary health gate
        if primary_degraded:
            primary_flag_bad = rng.random() < 0.95
        else:
            primary_flag_bad = rng.random() < 0.02

        if primary_flag_bad:
            freeze_hier += 1
            continue

        # 2) secondary diagnosis against primary
        if secondary_degraded:
            secondary_flag_bad = rng.random() < 0.90
        else:
            secondary_flag_bad = rng.random() < 0.03

        if secondary_flag_bad:
            # repair/recalibrate secondary, do not recalibrate sensor
            continue

        if sensor_drift:
            calibrations_hier += 1
            if primary_degraded:
                false_hier += 1

    return {
        "single_false_sensor_recalib_rate": false_single / max(1, calibrations_single),
        "hierarchical_false_sensor_recalib_rate": false_hier / max(1, calibrations_hier),
        "hierarchical_freeze_rate": freeze_hier / runs,
        "hierarchical_sensor_recalib_rate": calibrations_hier / runs,
    }


# ---------------------------------------------------------------------------
# 10) Physical coherence with hardware recalibration
# ---------------------------------------------------------------------------
def simulate_physical_recalibration(
    *,
    seed: int,
    runs: int = 1200,
    horizon: int = 120,
    tau_phys: float = 0.12,
) -> Dict[str, float]:
    legit_total = 0
    block_without = 0
    block_with = 0
    recovered = 0
    spoof_total = 0
    spoof_detected = 0

    for r in range(runs):
        rng = random.Random(seed + r * 41)

        spoof = rng.random() < 0.18
        drift = rng.uniform(0.0004, 0.0010)
        bias = rng.uniform(0.0, 0.015)
        attack_epoch = rng.randint(30, 90) if spoof else None

        blocked_no = False
        for t in range(1, horizon + 1):
            resid = bias + drift * t + rng.gauss(0.0, 0.014)
            if spoof and t >= attack_epoch:
                resid += 0.15 + rng.gauss(0.0, 0.02)
            if resid > tau_phys:
                blocked_no = True
                break

        blocked_with = False
        offset = 0.0
        recalib_used = False
        for t in range(1, horizon + 1):
            resid_true = bias + drift * t + rng.gauss(0.0, 0.014)
            spoof_flag = False
            if spoof and t >= attack_epoch:
                resid_true += 0.15 + rng.gauss(0.0, 0.02)
                spoof_flag = True

            resid = resid_true - offset
            if resid > tau_phys:
                if (not spoof_flag) and (not recalib_used):
                    recalib_used = True
                    if rng.random() > 0.90:
                        blocked_with = True
                        break
                    offset += resid_true - 0.082
                else:
                    blocked_with = True
                    break

        if spoof:
            spoof_total += 1
            if blocked_with:
                spoof_detected += 1
        else:
            legit_total += 1
            if blocked_no:
                block_without += 1
            if blocked_with:
                block_with += 1
            if blocked_no and (not blocked_with):
                recovered += 1

    return {
        "block_rate_without_recalib": block_without / legit_total,
        "block_rate_with_recalib": block_with / legit_total,
        "recovery_rate": (recovered / block_without) if block_without else 0.0,
        "spoof_detection_rate": (spoof_detected / spoof_total) if spoof_total else 0.0,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def run_all() -> Dict[str, object]:
    outlier = {
        "A": simulate_outlier_scenario(mean_gain=0.064, outlier_rate=0.015, seed=BASE_SEED + 0),
        "B": simulate_outlier_scenario(mean_gain=0.064, outlier_rate=0.050, seed=BASE_SEED + 100),
        "Null": simulate_outlier_scenario(mean_gain=0.0, outlier_rate=0.015, seed=BASE_SEED + 200),
    }

    drift = simulate_drift_recovery(seed=BASE_SEED + 300)
    byzantine = simulate_byzantine_growth(seed=BASE_SEED + 400)

    novelty_baseline = simulate_novelty_dynamics(defended=False, seed=BASE_SEED + 500)
    novelty_defended = simulate_novelty_dynamics(defended=True, seed=BASE_SEED + 500)

    adaptive_alt_base = simulate_adaptive_contextual(
        policy_pi=[0.5, 0.3, 0.2], alt=True, seed=BASE_SEED + 600
    )
    adaptive_alt_adaptive = simulate_adaptive_contextual(
        policy_pi=[0.4, 0.25, 0.35], alt=True, seed=BASE_SEED + 600
    )
    adaptive_null_base = simulate_adaptive_contextual(
        policy_pi=[0.5, 0.3, 0.2], alt=False, seed=BASE_SEED + 600
    )
    adaptive_null_adaptive = simulate_adaptive_contextual(
        policy_pi=[0.4, 0.25, 0.35], alt=False, seed=BASE_SEED + 600
    )

    ips_paralysis = simulate_ips_paralysis_stress(seed=BASE_SEED + 650)
    root_debt_attack = simulate_root_debt_attack(seed=BASE_SEED + 675)
    fault_localization = simulate_fault_localization(seed=BASE_SEED + 690)
    sentinel_hierarchy = simulate_sentinel_hierarchy(seed=BASE_SEED + 695)

    physical_recalibration = simulate_physical_recalibration(seed=BASE_SEED + 700)

    return {
        "seed": BASE_SEED,
        "outlier": outlier,
        "drift": drift,
        "byzantine": byzantine,
        "novelty_baseline": novelty_baseline,
        "novelty_defended": novelty_defended,
        "adaptive_alt_base": adaptive_alt_base,
        "adaptive_alt_adaptive": adaptive_alt_adaptive,
        "adaptive_null_base": adaptive_null_base,
        "adaptive_null_adaptive": adaptive_null_adaptive,
        "ips_paralysis_stress": ips_paralysis,
        "root_debt_attack": root_debt_attack,
        "fault_localization": fault_localization,
        "sentinel_hierarchy": sentinel_hierarchy,
        "physical_recalibration": physical_recalibration,
    }


def manuscript_expected_values(results: Dict[str, object]) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    outlier = results["outlier"]  # type: ignore[index]
    for key in ("A", "B", "Null"):
        d = outlier[key]  # type: ignore[index]
        out.extend(
            [
                (f"outlier_{key}_strict_abort", f"{d['strict_abort']:.3f}"),
                (f"outlier_{key}_strict_full", f"{d['strict_full']:.3f}"),
                (f"outlier_{key}_sanitized_full", f"{d['sanitized_full']:.3f}"),
                (f"outlier_{key}_integrity_fail", f"{d['integrity_fail']:.3f}"),
            ]
        )

    drift = results["drift"]  # type: ignore[index]
    out.extend(
        [
            ("drift_exit_rate", f"{drift['exit_rate']:.3f}"),
            ("drift_stuck_rate", f"{drift['stuck_rate']:.3f}"),
            ("drift_median_exit", str(int(drift["median_exit"]))),
            ("drift_p90_exit", str(int(drift["p90_exit"]))),
        ]
    )

    nov_b = results["novelty_baseline"]  # type: ignore[index]
    nov_d = results["novelty_defended"]  # type: ignore[index]
    out.extend(
        [
            ("novelty_mean_nu_base", f"{nov_b['mean_final_nu']:.3f}"),
            ("novelty_mean_nu_def", f"{nov_d['mean_final_nu']:.3f}"),
            ("novelty_accept_base", f"{nov_b['honest_accept_rate']:.3f}"),
            ("novelty_accept_def", f"{nov_d['honest_accept_rate']:.3f}"),
        ]
    )

    byz = results["byzantine"]  # type: ignore[index]
    out.extend(
        [
            ("byz_cross_rate", f"{byz['cross_rate']:.3f}"),
            ("byz_median_cross", str(int(byz["median_cross"]))),
            ("byz_p90_cross", str(int(byz["p90_cross"]))),
        ]
    )

    a_base = results["adaptive_alt_base"]  # type: ignore[index]
    a_adap = results["adaptive_alt_adaptive"]  # type: ignore[index]
    n_base = results["adaptive_null_base"]  # type: ignore[index]
    n_adap = results["adaptive_null_adaptive"]  # type: ignore[index]
    out.extend(
        [
            ("adaptive_alt_cross_base", f"{a_base['cross_rate']:.3f}"),
            ("adaptive_alt_cross_adap", f"{a_adap['cross_rate']:.3f}"),
            ("adaptive_alt_loge_base", f"{a_base['mean_log_e']:.3f}"),
            ("adaptive_alt_loge_adap", f"{a_adap['mean_log_e']:.3f}"),
            ("adaptive_null_cross_base", f"{n_base['cross_rate']:.4f}"),
            ("adaptive_null_cross_adap", f"{n_adap['cross_rate']:.4f}"),
            ("adaptive_cw_base", f"{a_base['max_weight_ratio']:.2f}"),
            ("adaptive_cw_adap", f"{a_adap['max_weight_ratio']:.2f}"),
        ]
    )

    ips = results["ips_paralysis_stress"]  # type: ignore[index]
    ips_alt = ips["alternative"]
    ips_null = ips["null"]
    out.extend(
        [
            ("ips_alt_cross_fixed", f"{ips_alt['fixed_cross_rate']:.3f}"),
            ("ips_alt_cross_adap", f"{ips_alt['adaptive_cross_rate']:.3f}"),
            ("ips_alt_loge_fixed", f"{ips_alt['fixed_mean_log_e']:.3f}"),
            ("ips_alt_loge_adap", f"{ips_alt['adaptive_mean_log_e']:.3f}"),
            ("ips_null_cross_fixed", f"{ips_null['fixed_cross_rate']:.3f}"),
            ("ips_null_cross_adap", f"{ips_null['adaptive_cross_rate']:.3f}"),
        ]
    )

    root = results["root_debt_attack"]  # type: ignore[index]
    out.extend(
        [
            ("root_m_legacy", str(int(root["median_m_legacy"]))),
            ("root_m_defended", str(int(root["median_m_defended"]))),
            ("root_kappa_legacy", f"{root['median_kappa_legacy']:.3f}"),
            ("root_kappa_defended", f"{root['median_kappa_defended']:.3f}"),
            ("root_low_legacy", f"{root['low_kappa_rate_legacy']:.3f}"),
            ("root_low_defended", f"{root['low_kappa_rate_defended']:.3f}"),
        ]
    )

    fault = results["fault_localization"]  # type: ignore[index]
    out.extend(
        [
            ("fault_uptime_global", f"{fault['unaffected_uptime_global_freeze']:.3f}"),
            ("fault_uptime_local", f"{fault['unaffected_uptime_localized']:.3f}"),
            ("fault_false_local", f"{fault['false_local_quarantine_rate']:.4f}"),
        ]
    )

    sent = results["sentinel_hierarchy"]  # type: ignore[index]
    out.extend(
        [
            ("sentinel_single_false", f"{sent['single_false_sensor_recalib_rate']:.3f}"),
            ("sentinel_hier_false", f"{sent['hierarchical_false_sensor_recalib_rate']:.3f}"),
            ("sentinel_hier_freeze", f"{sent['hierarchical_freeze_rate']:.3f}"),
        ]
    )

    phys = results["physical_recalibration"]  # type: ignore[index]
    out.extend(
        [
            ("phys_block_without", f"{phys['block_rate_without_recalib']:.3f}"),
            ("phys_block_with", f"{phys['block_rate_with_recalib']:.3f}"),
            ("phys_recovery", f"{phys['recovery_rate']:.3f}"),
            ("phys_spoof_detect", f"{phys['spoof_detection_rate']:.3f}"),
        ]
    )
    return out


def verify_manuscript_consistency(results: Dict[str, object]) -> Dict[str, object]:
    canonical = Path("Audit-Closed AI Scientist Protocol.tex")
    if canonical.exists():
        target: Optional[Path] = canonical
    else:
        candidates = [p for p in Path(".").glob("*.tex") if p.is_file()]
        target = max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None

    expected = manuscript_expected_values(results)
    if target is None:
        return {
            "checked_file": None,
            "checked_scope": None,
            "all_expected_values_present": False,
            "expected_count": len(expected),
            "missing": [name for name, _ in expected],
        }

    tex = target.read_text(encoding="utf-8")
    start_marker = r"\section{Synthetic Self-Driving-Lab Demonstration}"
    end_marker = r"\section{Implementation and Reproducibility Commitments}"
    start = tex.find(start_marker)
    end = tex.find(end_marker)
    if start != -1 and end != -1 and start < end:
        scope = tex[start:end]
        checked_scope = "section_13_only"
    else:
        scope = tex
        checked_scope = "full_document_fallback"

    missing = [name for name, val in expected if val not in scope]
    return {
        "checked_file": str(target),
        "checked_scope": checked_scope,
        "all_expected_values_present": len(missing) == 0,
        "expected_count": len(expected),
        "missing": missing,
    }


def main() -> None:
    results = run_all()
    canonical_payload = json.dumps(results, sort_keys=True, separators=(",", ":")).encode("utf-8")
    results["reproducibility_manifest"] = {
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "script_sha256": sha256_file(Path(__file__)),
        "core_results_payload_sha256": sha256_bytes(canonical_payload),
    }
    results["manuscript_consistency_check"] = verify_manuscript_consistency(results)
    OUT_PATH.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print("Reproducibility run complete")
    print(f"seed: {results['seed']}")
    print(f"results: {OUT_PATH}")
    print("\nKey metrics:")

    out = results["outlier"]
    print(
        "outlier A/B/null sanitized full:",
        round(out["A"]["sanitized_full"], 4),
        round(out["B"]["sanitized_full"], 4),
        round(out["Null"]["sanitized_full"], 4),
    )
    print(
        "adaptive alt cross (base/adaptive):",
        round(results["adaptive_alt_base"]["cross_rate"], 4),
        round(results["adaptive_alt_adaptive"]["cross_rate"], 4),
    )
    print(
        "high-cw stress fixed/adaptive cross:",
        round(results["ips_paralysis_stress"]["alternative"]["fixed_cross_rate"], 4),
        round(results["ips_paralysis_stress"]["alternative"]["adaptive_cross_rate"], 4),
    )
    print(
        "root-debt median kappa legacy/defended:",
        round(results["root_debt_attack"]["median_kappa_legacy"], 4),
        round(results["root_debt_attack"]["median_kappa_defended"], 4),
    )
    print(
        "fault localization unaffected uptime global/local:",
        round(results["fault_localization"]["unaffected_uptime_global_freeze"], 4),
        round(results["fault_localization"]["unaffected_uptime_localized"], 4),
    )
    check = results["manuscript_consistency_check"]
    print(
        "manuscript consistency check:",
        "PASS" if check["all_expected_values_present"] else "FAIL",
        f"({check['checked_file']})",
    )


if __name__ == "__main__":
    main()
